﻿using BusinessLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter first number");
                int no1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter second number");
                int no2 = Convert.ToInt32(Console.ReadLine());
                int ans = no1 / no2;
                Products p = new Products();
                try
                {
                    Console.WriteLine("Enter number");
                    int i = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(ans);


                    Console.WriteLine("Enter Productid");
                    p.ProductID = Convert.ToInt32(Console.ReadLine());
                }

                catch (DivideByZeroException ex)
                {
                    Console.WriteLine("Inner try called ");
                    Console.WriteLine(ex.Message);

                }


            }
            catch (ProductIDNotFoundException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)
            {
                Console.WriteLine("Enter a numebr in a integer range");
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("I am called.....");

            }
            Console.ReadLine();
        }
    }
}

﻿using SOADemo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    enum CustomerType
    { 
    
    Platinum,
    Gold
    }

   public struct Emp
    {
       public int empid;
       public string ename;

       public void Print(int id,string n)
        {
            empid = id;
            ename = n;
            Console.WriteLine(empid);
            Console.WriteLine(ename);
        
        }

    }


    public struct SrEmp
    {
       
        int sal;
        public void Print(Emp emp,int s)
        {
            Console.WriteLine(emp.empid);
            Console.WriteLine(emp.ename);
            sal = s;
            Console.WriteLine(sal);
        }
    
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Emp emp = new Emp();
            emp.empid = 1;
            emp.ename   = "hello";
            SrEmp emp1 = new SrEmp();
            
            emp1.Print(emp,1000);

            //Emp e=new Emp();
            //e.Print(1, "Ana");
            
            //    ConsoleColor c = ConsoleColor.Green;
            //Console.BackgroundColor = c;
            //Console.BackgroundColor = (ConsoleColor)12;
            //Console.ForegroundColor= ConsoleColor.Blue;
            
            //CustomerType custType = (CustomerType)0;
            //Console.WriteLine(custType);

            //EntityOperations operations=new EntityOperations();
            //operations.FindById(1);
            //operations.Insert();
             

            //IAddOns addOns;
            //addOns = operations;
            //addOns.Connect();
            Console.ReadLine();

        }
    }
}

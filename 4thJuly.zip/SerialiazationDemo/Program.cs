﻿using BusinessLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace SerialiazationDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. XML Serialization \n2. XML Deserialization \n3.JSON Serialization \n4.JSON Deserialization");

            int choice=Convert.ToInt32(Console.ReadLine()); 
            switch (choice) {

                case 1:
                    Customer c=new Customer();
                    FileStream fs = null;
                    try
                    {
                        fs = new FileStream("custdata.xml", FileMode.Create, FileAccess.Write);
                        c.Custid = 100;
                        c.Custname = "Anuj";
                      
                        XmlSerializer ser = new XmlSerializer(typeof(Customer));
                        ser.Serialize(fs, c);
                        fs.Flush();
                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine(ex.Message);
                    }

                    finally
                    {
                        fs.Close();
                        fs.Dispose();

                    }
                    
                    break;
                case 2:
                    fs = new FileStream("custdata.xml", FileMode.Open, FileAccess.Read);
                    XmlSerializer ser1=new XmlSerializer(typeof(Customer));
                    Customer cobj=(Customer)ser1.Deserialize(fs);
                    Console.WriteLine(cobj.Custid);
                    Console.WriteLine(cobj.Custname);
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();

                    break; 
                case 3:break; 
                case 4:break;
            }
            Console.ReadLine();
        }
    }
}

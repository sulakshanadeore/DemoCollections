﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLibrary
{
    public class EmpCRUDOperations
    {
        static List<Employee> emplist = new List<Employee>(1);
         public EmpCRUDOperations()
        {


            Employee e1 = new Employee();
            e1.FirstName = "Raj";
            e1.Deptno = 10;
            e1.Salary = 33333;
            emplist.Add(e1);

            Employee e2 = new Employee();
            e2.FirstName = "Smita";
            e2.Deptno = 20;
            e2.Salary = 44444;
            emplist.Add(e2);


            emplist.Add(new Employee
            { FirstName = "Gauri", Deptno = 30, Salary = 55555 });
            
           
        }

public void AddEmployee(Employee employee)
        { 
        


            emplist.Add(employee);
        }

        public void DeleteEmployee(Employee employee)
        {

            Employee efound=emplist.Find(e=>e.FirstName==employee.FirstName);
            //Employee found=emplist.Where(e =>e.FirstName == employee.FirstName).First();
            emplist.Remove(efound);


        }
        //public void UpdateEmployee(Employee employee)
        //{

        //}
        //public Employee GetEmployee(int id) { }

        public List<Employee> GetEmployeesList() 
        {
            return emplist;


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOADemo
{
    public interface IOperations
    {
         void Insert();
         void Update();   
         void Delete();

         void DeleteAll();

     
    }

    public interface IMoreOperations
    {
        void FindById(int id);

        void ShowAll();

    }

    public interface IAddOns
    {
         void Connect();
    
    
    }


    public class EntityOperations : IOperations,IMoreOperations,IAddOns
    {
        public void Delete()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Delete Called");
        }

        public void DeleteAll()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Delete all Called");
        }

        public void FindById(int id)
        {
            // throw new NotImplementedException();
            Console.WriteLine("Find by id Called");
        }

        public void Insert()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Insert Called");

        }

        public void ShowAll()
        {
            //   throw new NotImplementedException();
            Console.WriteLine("Show all Called");
        }

        public void Update()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Update Called");
        }

        void IAddOns.Connect()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Connecting to DB server  Called");
        }
    }
}

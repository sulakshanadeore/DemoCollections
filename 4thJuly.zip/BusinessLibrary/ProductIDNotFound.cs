﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLibrary
{


	[Serializable]
	public class ProductIDNotFoundException : Exception
	{
		public ProductIDNotFoundException() { }
		public ProductIDNotFoundException(string message) : base(message) { }
		public ProductIDNotFoundException(string message, Exception inner) : base(message, inner) { }
		protected ProductIDNotFoundException(
		  System.Runtime.Serialization.SerializationInfo info,
		  System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
	}
}

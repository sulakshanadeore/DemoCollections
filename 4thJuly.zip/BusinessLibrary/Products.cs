﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLibrary
{
    public class Products
            {


		private int _prodid;

		public int ProductID
		{
			get { return _prodid; }
			set {
				if ((value <= 0) || (value>200)) 
				{
					throw new ProductIDNotFoundException("Enter valid product id");
				
				}
				else
				{
                    _prodid = value;
                }
            }
				
		}

	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLibrary
{
    [Serializable]
    public class Customer
    {
        public int Custid { get; set; }
        public string Custname { get; set; }

        [NonSerialized]
        private string _pass;

        private string Password
        {
            get { return _pass; }
            set { _pass = value; }
        }


    }
}

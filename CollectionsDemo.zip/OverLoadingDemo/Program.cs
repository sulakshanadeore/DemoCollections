﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OverLoadingLibrary;
namespace OverLoadingDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select Payment Gateway:");
            Console.WriteLine("\n1.Cash \n2.Debit Card \n3.CreditCard \n4.UPI \n5.Phone Pe");
            int userChoice = Convert.ToInt32(Console.ReadLine());

            PaymentGateway gateway = new PaymentGateway();
            Console.WriteLine("Enter amount");
            gateway.Amount=Convert.ToDouble(Console.ReadLine());
            bool paymentStatus;
             switch (userChoice)
            {

                case 1:
                     paymentStatus=gateway.Pay(gateway.Amount);
                    Console.WriteLine(paymentStatus);

                    break;
                case 2:
                    Console.WriteLine("Enter Debit Card no");
                    long debitNo=Convert.ToInt64(Console.ReadLine());
                    paymentStatus=gateway.Pay(debitNo,gateway.Amount);
                    Console.WriteLine(paymentStatus);
                    break;  
                case 3:
                    Console.WriteLine("Enter Debit Card no");
                    long creditno = Convert.ToInt64(Console.ReadLine());
                    paymentStatus = gateway.Pay(gateway.Amount,creditno);
                    Console.WriteLine(paymentStatus);

                    break;
                case 4:
                    Console.WriteLine("Enter UPI");
                    string upi=Console.ReadLine();
                    paymentStatus=gateway.Pay(gateway.Amount,upi);
                    Console.WriteLine(paymentStatus);
                    break;
                case 5:
                    Console.WriteLine("Enter phone pe number");
                    long no=Convert.ToInt64(Console.ReadLine());
                    Console.WriteLine("Enter pin");
                    int pin=Convert.ToInt32(Console.ReadLine());
                    gateway.Pay(no, pin, gateway.Amount);
                    Console.WriteLine(gateway.Msg);
                    break;

            }

            Console.ReadLine();
        }
    }
}

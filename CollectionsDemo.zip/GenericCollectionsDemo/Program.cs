﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using EntityLibrary;
namespace GenericCollectionsDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //List<int> list = new List<int>();
            //list.Add(1);
            //list.Add(2);
            //list.Add(3);
            char ans;
            EmpCRUDOperations operations = new EmpCRUDOperations();
            do
            {

                Console.WriteLine("Menu");
                Console.WriteLine("1.Add Employee 2. Show Employee List 3.Delete Employee");
                int choice = Convert.ToInt32(Console.ReadLine());
              
                Employee emp = new Employee();

                switch (choice)
                {
                    case 1:

                        Console.WriteLine("Enter First name ");
                        emp.FirstName = Console.ReadLine();
                        Console.WriteLine("enter salary");
                        emp.Salary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter deptno");
                        emp.Deptno = Convert.ToInt32(Console.ReadLine());
                        operations.AddEmployee(emp);

                        break;
                    case 2:
                        List<Employee> emplist = operations.GetEmployeesList();
                        foreach (var item in emplist)
                        {
                            Console.WriteLine(item.FirstName);
                            Console.WriteLine(item.Deptno);
                            Console.WriteLine(item.Salary);
                            Console.WriteLine();
                        }

                        break;
                    case 3:
                        Console.WriteLine("Enter First name ");
                        emp.FirstName = Console.ReadLine();
                        Console.WriteLine("enter salary");
                        emp.Salary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("enter deptno");
                        emp.Deptno = Convert.ToInt32(Console.ReadLine());
                        operations.DeleteEmployee(emp);
                        Console.WriteLine("Successfully removed");
                        break;
                    default:
                        break;
                }
                Console.WriteLine("do you want to continue in the app");
                ans = Convert.ToChar(Console.ReadLine());


            }
            while (ans == 'Y');
            if (ans=='N')
            {
                Console.WriteLine("Thanks for using the app");
                Console.ReadLine();


                Environment.Exit(1);
            }
            
            
            

            Console.ReadLine();

        }
    }
}

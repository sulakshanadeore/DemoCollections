﻿using System;
using System.Collections;//nongeneric
using System.Collections.Generic;//generid
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Hashtable s=new Hashtable();
            //s.Add(1, 100);
            //s.Add(12, 200);
            //s.Add("1", 500);
            //IDictionaryEnumerator ie = s.GetEnumerator();
            //while (ie.MoveNext())
            //{
            //    Console.WriteLine(ie.Key + "  " + ie.Value);
            //}




            SortedList s = new SortedList();
            s.Add("a", 100);
            s.Add("B", 200);
            s.Add("c", 500);


            foreach (DictionaryEntry item in s)
            {
                Console.WriteLine(item.Key + "  "+ item.Value);

            }

            //IDictionaryEnumerator ie=s.GetEnumerator();
            //while (ie.MoveNext())
            //{
            //    Console.WriteLine(ie.Key + "  " + ie.Value);
            //}






            //Queue q=new Queue();
            //q.Enqueue(1);
            //q.Enqueue(2);  
            //q.Enqueue(3);



            //Stack s=new Stack();
            //s.Push(1);
            //s.Push(2);
            //s.Push(3);
            //s.Push(4);
            //s.Push(5);






            //ArrayListdemo();


            //            WorkingWithArrays();
            //Stack s = new Stack();
            //s.Push(1);
            //s.Push(2.33f);
            //s.Push("Jack");
            //s.Push('A');
            //s.Pop();//A

            //var i = 'A';
            ////            i = "Hello";//not allowed in var

            ////dynamic y = 90;
            ////y = 6777.56f;
            //foreach (dynamic item in s)
            //{
            //    Console.WriteLine(item);

            //}



            Console.Read();
        }

        private static void ArrayListdemo()
        {
            ArrayList a = new ArrayList(2);
            a.Add(1);
            a.Add(333.44f);
            a.Add("HEllo");
            a.Add('A');

            int[] arr = new int[] { 1000, 1001, 1002 };
            a.Insert(0, 110);//110,1,333.44,"Hello",A
            a.InsertRange(0, arr);
            //1000,1001,1002,110,1,333.44,"Hello",A
            foreach (var item in a)
            {
                Console.WriteLine(item);

            }
            a.RemoveAt(0);
            Console.WriteLine("After removing");
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }
        }

        private static void WorkingWithArrays()
        {
            int[] arr = new int[] { 101, 11, 112, 4513, 1 };

            foreach (var element in arr)
            {
                Console.WriteLine(element);
            }
            int[] destArr = new int[5];

            Array.Sort(arr);
            Array.Reverse(arr);
            Console.WriteLine("Sorted Array");
            foreach (var element in arr)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("0--------0");
            Array.Copy(arr, destArr, 5);

            foreach (var item in destArr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("--------------");
            int index = Array.IndexOf(arr, 1);
            Console.WriteLine(index);
        }
    }
}

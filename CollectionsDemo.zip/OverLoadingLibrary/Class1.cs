﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverLoadingLibrary
{
    public class PaymentGateway
    {
        public string PaymentMode { get; set; }
        public double Amount { get; set; }

        public bool Pay(double amt) 
        {

            PaymentMode = "Cash";
            return true;


        }

        public bool Pay(double amt, string upi)
        { 
        PaymentMode= "upi";
            return true;

        
        }

        public bool Pay(double amt, long creditCardNo)
        {
            PaymentMode = "CreditCard";
            return true;


        }

        public bool Pay(long debitCardNo,double amt) {
            PaymentMode = "DebitCard";
            return true;

        }

        public void Pay(long mobileNo, int pin, double amt)
        {
            PaymentMode = "PhonePay";
            Msg = "Thank u for choosing phone pe";
         }

        public string Msg { get; set; }




    }
}
